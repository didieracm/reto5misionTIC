/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import acceso.PilotoDAO;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Piloto;

/**
 *
 * @author
 */
public class PilotoVista extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public PilotoVista() {
        initComponents();
    }
    // Método que limpia el JTable, recorre y setea vacio 
    public void limpiarPantalla(){
        DefaultTableModel modelo;
        modelo = (DefaultTableModel) jtEscuderia.getModel();
        for(int i=modelo.getRowCount()-1; i>=0 ; i--){
            modelo.removeRow(i);
        }
        txtId.setText("");
        txtPiloto.setText("");
        txtMIllas.setText("");
        txtCombustible.setText("");
        txtEscuderia.setText("");
    }
    // Recupera el dato del Id de la Piloto
    // Se hace parsing dependiendo de cada elemento
    public int getId(){
        return Integer.parseInt(txtId.getText().trim());
    }
    // Recupera el dato del nombre del piloto
    public String getNombre(){
        return txtPiloto.getText();
    }
    // Recupera el dato de las millas recorridas
    public float getMillas(){
        return Float.parseFloat(txtMIllas.getText());
    }
    // Recupera el dato del combustible utilizado
    public int getCombustible(){
        return Integer.parseInt(txtCombustible.getText());
    }
    // Recupera el id de la escuderia
    public int getIdEscuderia(){
        return Integer.parseInt(txtEscuderia.getText());
    }
    // Recupera el nombre de la escuderia traido de la relacion de tablas
    public String getEscuderia(){
        return txtEscuderia.getText();
    }
    
     // Métodos que agregan el ActionListener a cada control o botón utilizado     
    public void addListenerBtnCrear(ActionListener listenPrograma){
        btnCrear.addActionListener(listenPrograma);       
    }
    public void addListenerBtnModificar(ActionListener listenPrograma){
        btnModificar.addActionListener(listenPrograma);        
    }
    public void addListenerBtnEliminar(ActionListener listenPrograma){
        btnEliminar.addActionListener(listenPrograma);        
    }
    public void addListenerBtnCancelar(ActionListener listenPrograma){
        btnCancelar.addActionListener(listenPrograma);        
    }
    public void addListenerBtnGrabar(ActionListener listenPrograma){
        btnGrabar.addActionListener(listenPrograma);        
    }
    public void addListenerBtnActualizar(ActionListener listenPrograma){
        btnActualizar.addActionListener(listenPrograma);        
    }
    public void addListenerBtnLimpiar(ActionListener listenPrograma){
        btnLimpiar.addActionListener(listenPrograma);        
    }
    public void addListenerBtnSalir(ActionListener listenPrograma){
        btnSalir.addActionListener(listenPrograma);        
    } 
    //JoptionPane para darle estetica a los emnsajes en pantalla
    public void gestionMensajes(String mensaje, String titulo, int icono){
         JOptionPane.showMessageDialog(this,mensaje, titulo, icono);
    }
    
        // limpia la pantalla y la deja en su estado incial
        public void activarControles(boolean estado){
        txtId.setText("");
        txtPiloto.setText("");
        txtMIllas.setText("");
        txtCombustible.setText("");
        txtEscuderia.setText("");
        txtId.setEnabled(estado);
        txtPiloto.setEnabled(estado);
        txtMIllas.setEnabled(estado);
        txtCombustible.setEnabled(estado);
        txtEscuderia.setEnabled(estado);
        txtEscuderia.setEnabled(estado);
        jtEscuderia.setEnabled(!estado);
        btnCrear.setEnabled(!estado);
        btnModificar.setEnabled(!estado);
        btnEliminar.setEnabled(!estado);
        btnCancelar.setEnabled(estado);
        btnLimpiar.setEnabled(!estado);
        btnSalir.setEnabled(!estado);
        btnGrabar.setEnabled(estado);
        btnActualizar.setEnabled(estado);
        
    } 
    // actualiza el jtable despues de acciones como crear, moficar o eliminar
    public void cargarPiloto(ArrayList<Piloto> listadoPiloto){
        DefaultTableModel modelo;
        modelo = (DefaultTableModel) jtEscuderia.getModel();        
        limpiarPantalla();
        for(int i= 0; i < listadoPiloto.size(); i++){
              modelo.addRow(new Object[]{
                listadoPiloto.get(i).getId(),
                listadoPiloto.get(i).getNombre(),
                listadoPiloto.get(i).getMillas(),
                listadoPiloto.get(i).getCombustible(),
                listadoPiloto.get(i).getEscuderia()
              });
        }
    }
    // prepara la vista para crear un nuevo piloto
    public void Crear(boolean estado){              
        txtId.setEnabled(!estado);
        txtPiloto.setEnabled(!estado);
        txtMIllas.setEnabled(!estado);
        txtCombustible.setEnabled(!estado);
        txtEscuderia.setEnabled(!estado);
        txtId.setText("");
        txtPiloto.setText("");
        txtMIllas.setText("");
        txtCombustible.setText("");
        txtEscuderia.setText("");
        jtEscuderia.setEnabled(estado);
        btnCrear.setEnabled(estado);
        btnModificar.setEnabled(estado);
        btnEliminar.setEnabled(estado);
        btnCancelar.setEnabled(!estado);
        btnLimpiar.setEnabled(estado);
        btnSalir.setEnabled(estado);
        btnGrabar.setEnabled(!estado);
        btnActualizar.setEnabled(estado);
        txtId.requestFocusInWindow();
    }
    // prepra la vista para modificar un piloto
    public void Modificar(boolean estado){
        if(btnModificar.getText().equals("Modificar")){
            if(jtEscuderia.getSelectedRow() == -1){
               if(jtEscuderia.getRowCount() == 0){
                   JOptionPane.showMessageDialog(this," Cargue la tabla  y"
                           + " seleccione el registro a modificar");
               }
               else{
                   JOptionPane.showMessageDialog(this,"Seleccione un registro "
                           + "de la tabla");
               }
            }else{
                txtId.setEnabled(estado);
                txtPiloto.setEnabled(!estado);
                txtMIllas.setEnabled(!estado);
                txtCombustible.setEnabled(!estado);
                txtEscuderia.setEnabled(!estado);
                btnCrear.setEnabled(estado);
                btnModificar.setEnabled(estado);
                btnEliminar.setEnabled(estado);
                btnCancelar.setEnabled(!estado);
                btnActualizar.setEnabled(!estado);
                btnLimpiar.setEnabled(estado);
                btnSalir.setEnabled(estado);
                txtPiloto.requestFocusInWindow();
            }
        }
    }    
    // sale del programa
    public void salir(){
        System.exit(0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jtEscuderia = new javax.swing.JTable();
        btnCargar = new javax.swing.JButton();
        lblId = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblPatrocinador = new javax.swing.JLabel();
        lblCarreras = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtPiloto = new javax.swing.JTextField();
        txtMIllas = new javax.swing.JTextField();
        txtCombustible = new javax.swing.JTextField();
        btnCrear = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        lblIdEscuderia = new javax.swing.JLabel();
        txtEscuderia = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtEscuderia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Piloto", "Nombre", "Millas", "Combustible", "Id Escuderia"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jtEscuderia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtEscuderiaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtEscuderia);

        btnCargar.setText("Cargar Registros");
        btnCargar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarActionPerformed(evt);
            }
        });

        lblId.setText("Id Piloto");

        lblNombre.setText("Nonbre Piloto");

        lblPatrocinador.setText("Millas");

        lblCarreras.setText("Combustible");

        txtId.setEnabled(false);

        txtPiloto.setEnabled(false);

        txtMIllas.setEnabled(false);

        txtCombustible.setEnabled(false);

        btnCrear.setText("Crear");

        btnModificar.setText("Modificar");

        btnEliminar.setText("Eliminar");

        btnCancelar.setText("Cancelar");
        btnCancelar.setEnabled(false);

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");

        btnGrabar.setText("Grabar");
        btnGrabar.setEnabled(false);

        btnActualizar.setText("Actualizar");
        btnActualizar.setEnabled(false);

        lblIdEscuderia.setText("Id Escuderia");

        txtEscuderia.setEnabled(false);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel1.setText("Reto5 MisionTIC - Didier Castañeda");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblId)
                            .addComponent(lblNombre)
                            .addComponent(lblPatrocinador)
                            .addComponent(lblCarreras)
                            .addComponent(lblIdEscuderia))
                        .addGap(67, 67, 67)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtCombustible, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMIllas, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPiloto, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtId, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEscuderia, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE))
                        .addGap(32, 32, 32)
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(btnCrear, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(btnModificar)
                        .addGap(31, 31, 31)
                        .addComponent(btnEliminar)
                        .addGap(32, 32, 32)
                        .addComponent(btnGrabar, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(btnActualizar)
                        .addGap(38, 38, 38)
                        .addComponent(btnCancelar)
                        .addGap(34, 34, 34)
                        .addComponent(btnLimpiar)
                        .addGap(30, 30, 30)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(138, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnCargar, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(167, 167, 167))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCargar)
                    .addComponent(jLabel1))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblId)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNombre)
                            .addComponent(txtPiloto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblPatrocinador)
                            .addComponent(txtMIllas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCarreras)
                            .addComponent(txtCombustible, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblIdEscuderia)
                            .addComponent(txtEscuderia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnModificar)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCrear)
                        .addComponent(btnEliminar)
                        .addComponent(btnGrabar)
                        .addComponent(btnActualizar)
                        .addComponent(btnCancelar)
                        .addComponent(btnLimpiar)
                        .addComponent(btnSalir)))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

// metodo para el boton cargar registros
   
    private void btnCargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarActionPerformed
        // TODO add your handling code here:
        PilotoDAO escuderia = new PilotoDAO();
        ArrayList<Piloto> listadoPiloto;
        listadoPiloto = escuderia.getListPiloto(0);
        
        DefaultTableModel modelo;
        modelo = (DefaultTableModel) jtEscuderia.getModel();        
        limpiarPantalla();
        for(int i= 0; i < listadoPiloto.size(); i++){
              modelo.addRow(new Object[]{
                listadoPiloto.get(i).getId(),
                listadoPiloto.get(i).getNombre(),
                listadoPiloto.get(i).getMillas(),
                listadoPiloto.get(i).getCombustible(),
                //listadoPiloto.get(i).getIdEscuderia(),
                listadoPiloto.get(i).getEscuderia()
              });
        }
    }//GEN-LAST:event_btnCargarActionPerformed
// metodo para capturar datos del jtable y pasarlo a los campos de texto
    private void jtEscuderiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtEscuderiaMouseClicked
        // TODO add your handling code here:
        DefaultTableModel modelo;
        modelo = (DefaultTableModel) jtEscuderia.getModel();
                    
        if(jtEscuderia.getSelectedRow()==-1){
            if(jtEscuderia.getRowCount()==0){
                JOptionPane.showMessageDialog(this,"Tabla vacia");
            }
            else{
                JOptionPane.showMessageDialog(this,"Seleccione un registro de "
                        + "la tabla");
            }
        }else {                     
            txtId.setText(modelo.getValueAt(
                    jtEscuderia.getSelectedRow(), 0).toString());            
            txtPiloto.setText(modelo.getValueAt(
                    jtEscuderia.getSelectedRow(), 1).toString());
            txtMIllas.setText(modelo.getValueAt(
                    jtEscuderia.getSelectedRow(), 2).toString());
            txtCombustible.setText(modelo.getValueAt(
                    jtEscuderia.getSelectedRow(), 3).toString());
            //txtEscuderia.setText(modelo.getValueAt(
                    //jtEscuderia.getSelectedRow(), 5).toString());
        }
        
    }//GEN-LAST:event_jtEscuderiaMouseClicked

// metodo para limpiar pantalla
    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        DefaultTableModel modelo;
        modelo = (DefaultTableModel) jtEscuderia.getModel();
        for(int i=modelo.getRowCount()-1; i>=0 ; i--){
            modelo.removeRow(i);
        }
        txtId.setText("");
        txtPiloto.setText("");
        txtMIllas.setText("");
        txtCombustible.setText("");
        txtEscuderia.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PilotoVista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PilotoVista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PilotoVista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PilotoVista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PilotoVista().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnActualizar;
    public javax.swing.JButton btnCancelar;
    public javax.swing.JButton btnCargar;
    public javax.swing.JButton btnCrear;
    public javax.swing.JButton btnEliminar;
    public javax.swing.JButton btnGrabar;
    public javax.swing.JButton btnLimpiar;
    public javax.swing.JButton btnModificar;
    public javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jtEscuderia;
    public javax.swing.JLabel lblCarreras;
    public javax.swing.JLabel lblId;
    private javax.swing.JLabel lblIdEscuderia;
    public javax.swing.JLabel lblNombre;
    public javax.swing.JLabel lblPatrocinador;
    public javax.swing.JTextField txtCombustible;
    public javax.swing.JTextField txtEscuderia;
    public javax.swing.JTextField txtId;
    public javax.swing.JTextField txtMIllas;
    public javax.swing.JTextField txtPiloto;
    // End of variables declaration//GEN-END:variables
}
