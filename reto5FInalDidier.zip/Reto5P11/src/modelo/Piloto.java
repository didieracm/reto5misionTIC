/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

//import java.sql.Date;
/**
 *
 * @author didie
 */
public class Piloto {
    
    private int id;
    private String nombre;
    private float millas;
    private int combustible;
    private int idEscuderia;
    private String escuderia;
    
    
    // Método constructor con parametros
    public Piloto(int id, String nombre, float millas, int combustible ,int idEscuderia) {
        this.id = id;
        this.nombre = nombre;
        this.millas = millas;
        this.combustible = combustible;
        this.idEscuderia = idEscuderia;
        this.escuderia = escuderia;
    }
    
    // Método contructos sin parametros
    public Piloto() {
        this.id = 0;
        this.nombre = "";
        this.millas = 0;
        this.combustible = 0;
        this.idEscuderia = 0;
        this.escuderia = "";
    }
    
    public int getId() {
        return id;
    }
    // geters y setes de ka clase
    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getMillas() {
        return millas;
    }

    public void setMillas(float millas) {
        this.millas = millas;
    }

    public int getCombustible() {
        return combustible;
    }

    public void setCombustible(int combustible) {
        this.combustible = combustible;
    }

    public int getIdEscuderia() {
        return idEscuderia;
    }

    public void setIdEscuderia(int idEscuderia) {
        this.idEscuderia = idEscuderia;
    }

    public String getEscuderia() {
        return escuderia;
    }

    public void setEscuderia(String escuderia) {
        this.escuderia = escuderia;
    }

    
    
}
