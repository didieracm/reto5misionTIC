/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import acceso.PilotoDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Piloto;
import vista.PilotoVista;

/**
 *
 * @author didie
 */
// "conexion" entre Vista y DAO
public class PilotoContolador {

    private PilotoVista vista;
    private PilotoDAO modelo;

    public PilotoContolador(PilotoVista vista, PilotoDAO modelo) {
        this.vista = vista;
        this.modelo = modelo;
        
        //acciones Listener para cada boton
        this.vista.addListenerBtnCrear(new PilotoListener());
        this.vista.addListenerBtnModificar(new PilotoListener());
        this.vista.addListenerBtnGrabar(new PilotoListener());
        this.vista.addListenerBtnCancelar(new PilotoListener());
        this.vista.addListenerBtnActualizar(new PilotoListener());
        this.vista.addListenerBtnEliminar(new PilotoListener());
        this.vista.addListenerBtnSalir(new PilotoListener());
        

    }
    class PilotoListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e){
            if(e.getActionCommand().equalsIgnoreCase("crear")){
                vista.Crear(false);
            }else if(e.getActionCommand().equalsIgnoreCase("cancelar")){
                vista.activarControles(false);
            }else if(e.getActionCommand().equalsIgnoreCase("modificar")){
                vista.Modificar(false);
            }else if(e.getActionCommand().equalsIgnoreCase("salir")){
                vista.salir();
            }else if(e.getActionCommand().equalsIgnoreCase("grabar")){
                registrar();
            }else if(e.getActionCommand().equalsIgnoreCase("eliminar")){
                borrar();
            }else if(e.getActionCommand().equalsIgnoreCase("actualizar")){
                actualizar();
            }
        } 
        // Método para registrar un nuevo piloto en la BD
        private void registrar(){
            if(vista.txtId.getText().equals("")){
            //if(vista.getId()== 0){
                vista.gestionMensajes("Ingrese los datos del nuevo del "
                        + "piloto", "Aviso", JOptionPane.ERROR_MESSAGE);
            }else{
                Piloto piloto = new Piloto();
                piloto.setId(vista.getId());
                piloto.setNombre(vista.getNombre());
                piloto.setMillas(vista.getMillas());
                piloto.setCombustible(vista.getCombustible());
                piloto.setIdEscuderia(vista.getIdEscuderia());
                
                int tamaño;
                tamaño = modelo.getListPiloto(piloto.getId()).size();
                if(tamaño == 0){
                    int resultado = 0;
                    resultado = modelo.nuevoPiloto(piloto);
                    if(resultado == 1){
                        vista.gestionMensajes("Su registro fue almacenado",
                                "Aviso",JOptionPane.INFORMATION_MESSAGE);                        
                        ArrayList<Piloto> listadoPiloto;
                        listadoPiloto = modelo.getListPiloto(0);
                        vista.cargarPiloto(listadoPiloto);
                        vista.activarControles(false);
                    }else{
                        vista.gestionMensajes("su registro no fue almacenado",
                                "Alerta",JOptionPane.ERROR);
                    }
                }else{
                    vista.gestionMensajes("El registro ya existe",
                            "Advertencia",JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        // Método borrar un piloto de la BD
        private void borrar(){

            if(vista.txtId.getText().equals("")){
                vista.gestionMensajes("Cargue los registros y seleccione "
                        + "de la lista el registro a eliminar",
                        "Aviso",JOptionPane.ERROR_MESSAGE);
            }else{
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Desea Eleminar al piloto con Id: " +
                        vista.getId()+ " ?", "Advertencia",
                        JOptionPane.YES_NO_OPTION);
                
                if(respuesta == JOptionPane.YES_NO_OPTION){
                    if(modelo.eliminarPiloto(vista.getId()) == 1){
                        JOptionPane.showMessageDialog(null,
                                "Su registro fue eliminado",
                                "Aviso",
                                JOptionPane.INFORMATION_MESSAGE);
                        vista.limpiarPantalla();
                        ArrayList<Piloto> listadoPiloto;
                        listadoPiloto = modelo.getListPiloto(0);
                        vista.cargarPiloto(listadoPiloto);
                    }else{
                        JOptionPane.showMessageDialog(null,"NO fue posible "
                                + "borrar su registro", "Alerta",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
        // Método para actulizar un piloto en la BD
        private void actualizar(){
            // creacion de un objeto Piloto
            Piloto piloto = new Piloto();
            piloto.setId(vista.getId());
            piloto.setNombre(vista.getNombre());
            piloto.setMillas(vista.getMillas());
            piloto.setCombustible(vista.getCombustible());
            piloto.setIdEscuderia(vista.getIdEscuderia());
           if(modelo.actualizarPiloto(piloto) == 1){
                vista.gestionMensajes("Registro Actualizado","Anuncio",
                        JOptionPane.INFORMATION_MESSAGE);
                vista.activarControles(false);
                ArrayList<Piloto> listadoPiloto;
                listadoPiloto = modelo.getListPiloto(0);
                vista.cargarPiloto(listadoPiloto);
            }
        } 
    } 

}
