/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import acceso.PilotoDAO;
import controlador.PilotoContolador;
//import java.util.ArrayList;
//import modelo.Piloto;
import vista.PilotoVista;

/**
 *
 * @author didie
 */
public class Principal {
    public static void main(String[] args) {
        PilotoVista gui = new PilotoVista();
        gui.setTitle("Pilotos Formula Tapitas");
        gui.setEnabled(true);
        gui.setVisible(true);
        PilotoDAO pilotoDao = new PilotoDAO();
        PilotoContolador pacienteContolador = new PilotoContolador(gui,pilotoDao);
        
       
       
    }
    
}
