/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acceso;

//import java.sql.ResultSetMetaData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Piloto;
import servicios.Conexion;

/**
 *
 * @author didie 
 */
public class PilotoDAO {
    
    /**
     * 
     * @param id_piloto
     * @return un ArrayList con los datos genrados de la consulta a la BD
     */
    // generar consulta por medio de ArrayList con la PK como parametro 
    public ArrayList<Piloto> getListPiloto(int id_piloto) {
        Connection con = null;
        //preparedStatment aumenta seguridad
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Piloto> listadoPiloto = new ArrayList();
        try {
            con = Conexion.getConnection();
            String sql = "";
            if (id_piloto == 0) {
                sql = "SELECT id_piloto, nom_piloto, millas, combustible, "
                        + "id_escuderia, nom_escuderia FROM piloto JOIN escuderia "
                        + "ON(escuderia_id = id_escuderia)";
            } else {
                sql = "SELECT id_piloto, nom_piloto, millas, combustible, "
                        + "id_escuderia, nom_escuderia FROM piloto JOIN escuderia "
                        + "ON(escuderia_id = id_escuderia) WHERE id_piloto"
                        + "= ?";
            }
            ps = con.prepareStatement(sql);
            if (id_piloto != 0) {
                ps.setInt(1, id_piloto);
            }
            rs = ps.executeQuery();
            Piloto piloto = null;
            while (rs.next()) {
                piloto = new Piloto();
                piloto.setId(rs.getInt("id_piloto"));
                piloto.setNombre(rs.getString("nom_piloto"));
                piloto.setMillas(rs.getFloat("millas"));
                piloto.setCombustible(rs.getInt("combustible"));
                piloto.setIdEscuderia(rs.getInt("id_escuderia"));
                piloto.setEscuderia(rs.getString("nom_escuderia"));
                listadoPiloto.add(piloto);
            }
            //Manejo de excepciones y para cerrar conexiones
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
            }
        }
        return listadoPiloto;
    }
    // Método con sentencia para la creacion de un nuevo piloto
    //Update a BD
    public int nuevoPiloto (Piloto piloto) {
        Connection con = null;
        PreparedStatement ps = null;
        int resultado = 0;
        try {
            con = Conexion.getConnection();
            String sql = "";
            sql = "INSERT INTO piloto VALUES (?, ?, ?, ?, ?)";
            ps = con.prepareStatement(sql);
            ps.setInt(1, piloto.getId());
            ps.setString(2, piloto.getNombre());
            ps.setFloat(3, piloto.getMillas());
            ps.setInt(4, piloto.getCombustible());
            ps.setInt(5 , piloto.getIdEscuderia());
            resultado = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
            }
        }
        return resultado;
    }
    // Método con sentencia para eliminar un piloto
    public int eliminarPiloto (int id_piloto) {
        Connection con = null;
        PreparedStatement ps = null;
        int resultado = 0;
        try {
            con = Conexion.getConnection();
            String sql = "";
            sql = "DELETE FROM piloto WHERE id_piloto = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id_piloto);
            resultado = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
            }
        }
        return resultado;
    }
        // Método con sentencia para actualizar el registro de un piloto
        public int actualizarPiloto (Piloto piloto) {
        Connection con = null;
        PreparedStatement ps = null;
        int resultado = 0;
        try {
            con = Conexion.getConnection();
            String sql = "";
            sql = "UPDATE piloto set nom_piloto = ?,millas = ?, "
                    + "combustible = ?, escuderia_id = ? WHERE id_piloto = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, piloto.getNombre());
            ps.setFloat(2, piloto.getMillas());
            ps.setInt(3, piloto.getCombustible());
            ps.setInt(4, piloto.getIdEscuderia());
            ps.setInt(5, piloto.getId());
            resultado = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error" + ex.getMessage());
            }
        }
        return resultado;
    }
    
}
